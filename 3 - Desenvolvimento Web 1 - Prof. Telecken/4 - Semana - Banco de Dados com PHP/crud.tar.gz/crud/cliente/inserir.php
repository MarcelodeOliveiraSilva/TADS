<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Inserir</title>
</head>
<body>

 <br>
  <form method="POST" action="./inserir2.php">
     Nome: <input type=text name="nome"> <br />
     CPF: <input type=text name="cpf"> <br />
    <hr />
    <input type="submit" name="submit" value="inserir">
  </form>


</body>
</html>
